﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi segundo Programa");
            Console.WriteLine("Ingrese Nombre");
            string Nombre = Console.ReadLine();
            Console.WriteLine("Ingrese Edad");
            string Edad = Console.ReadLine();
            Console.WriteLine("Ingrese Carrera");
            string Carrera = Console.ReadLine();
            Console.WriteLine("Ingrese Carne");
            string Carne = Console.ReadLine();
            Console.WriteLine("Mi segundo Programa");
            Console.WriteLine("Nombre: " + Nombre);
            Console.WriteLine("Edad: " + Edad);
            Console.WriteLine("Carrera: " + Carrera);
            Console.WriteLine("Carne: " + Carne);
            Console.WriteLine("Soy " + Nombre + ", tengo " + Edad + " años y estudio la carrera de " + Carrera + ". "
             + "Mi número de carné es " + Carne);
            Console.ReadKey();
        }
    }


