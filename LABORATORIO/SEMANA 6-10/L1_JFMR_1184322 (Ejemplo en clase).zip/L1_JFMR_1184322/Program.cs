﻿using System;

namespace L1_JFMR_1184322
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese su nombre: ");
            String nombre = Console.ReadLine();

            Console.WriteLine("Hola Mundo");
            Console.WriteLine("soy " + nombre);

            Console.Write("Hola Mundo ");
            Console.Write("soy " + nombre);
            Console.ReadKey();
        }
    }
}
