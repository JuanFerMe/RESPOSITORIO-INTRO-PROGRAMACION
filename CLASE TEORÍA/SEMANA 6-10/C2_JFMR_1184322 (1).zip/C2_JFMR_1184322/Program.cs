﻿// See https://aka.ms/new-console-template for more information
String palabra;
int i;
for (i = 0; i <= 9; i++)
{
    Console.WriteLine("\n \nIngrese una palabra: ");
    palabra = Console.ReadLine();
    string aux = palabra.ToUpper();
    if (palabra == aux)
    {
        Console.WriteLine("Es una palabra molesta");
    }
    else
    {
        if (palabra.Contains("!"))
        {
            Console.WriteLine("Es una palabra molesta");
        }
        else
        {
            if (palabra.Contains("¡"))
            {
                Console.WriteLine("Es una palabra molesta");
            }
            else 
            {
                if (palabra != aux);
                {
                    Console.WriteLine("No es una palabra molesta");
                }
            }
        }
    }

}
Console.ReadKey();

