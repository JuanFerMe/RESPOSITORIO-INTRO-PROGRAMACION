﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Ejercicio entradas al cine");

int edad, precio;
string clasificacion, adulto;

Console.WriteLine("=====Bienvenido al cine====");
Console.WriteLine("Ingrese edad: ");
edad = Convert.ToInt32(Console.ReadLine());

if (edad<10)
{
    Console.WriteLine("El costo de la entrada es Q. 0.00");
}
else
{
    if (edad > 10 && edad < 15);
}
Console.WriteLine("Estas siendo acompanado de un adulto?(si/no)");
 adulto = Console.ReadLine().ToString();

if (adulto.ToLower() == "si")
{
    clasificacion = "PG15";
}
else
{
    clasificacion = "PG13";

}
precio = 15;



if (edad > 15 && edad < 21) 
{
 Console.WriteLine("PG15");
 precio = 25;
} 


if (edad >21 && edad <60)
{
    Console.WriteLine("Puede ver todas");
    precio = 35;
}

if (edad > 60)
{
    Console.WriteLine("Puede ver todas");
    precio = 0;
}


Console.WriteLine("El costo de entrada es " + precio +
    " y la clasificación es " + clasificacion);

